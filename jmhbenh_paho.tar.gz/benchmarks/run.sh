OUTPUT_FILE=$(date +"%Y%m%d_%H%M%S")
java -jar target/benchmarks.jar \
     -bm Throughput \
     -f 1 \
     -i 5 \
     -rff "./result_"$OUTPUT_FILE".json" \
     -rf JSON \
     -w 1000 \
	SimplePublisher
