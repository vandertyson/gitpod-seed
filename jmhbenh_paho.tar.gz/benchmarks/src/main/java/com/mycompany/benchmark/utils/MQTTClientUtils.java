package com.mycompany.benchmark.utils;

import java.util.UUID;

import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

public class MQTTClientUtils {
    private IMqttClient publisher;

    public MQTTClientUtils() throws MqttException {
        String publisherId = UUID.randomUUID().toString();
        publisher = new MqttClient("tcp://iot.eclipse.org:1883", publisherId);

        MqttConnectOptions options = new MqttConnectOptions();
        options.setAutomaticReconnect(false);
        options.setCleanSession(true);
        options.setConnectionTimeout(10);
        publisher.connect(options);
    }
}