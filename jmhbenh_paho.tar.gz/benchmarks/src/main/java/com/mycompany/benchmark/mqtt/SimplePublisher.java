package com.mycompany.benchmark.mqtt;

import java.util.concurrent.TimeUnit;

import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.results.format.ResultFormatType;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.openjdk.jmh.runner.options.TimeValue;

public class SimplePublisher {
    @State(Scope.Thread)
    public static class Data {
        double x1 = 0.0;
        double y1 = 0.0;
        double x2 = 10.0;
        double y2 = 10.0;
    }

    public static double distance(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        return Math.sqrt((dx * dx) + (dy * dy));
    }
    
    public double distance(Data data) {
        return distance(data.x1, data.y1, data.x2, data.y2);
    }

    public static void main(String[] args) throws RunnerException {

        Options opt = new OptionsBuilder().include(SimplePublisher.class.getSimpleName()).forks(1).warmupIterations(5)
                .measurementIterations(5).measurementTime(TimeValue.milliseconds(5000)).result("~/results.json")
                .resultFormat(ResultFormatType.JSON).build();
        new Runner(opt).run();
    }
}