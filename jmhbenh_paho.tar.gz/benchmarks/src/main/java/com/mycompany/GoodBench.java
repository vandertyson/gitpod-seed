package com.mycompany;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.openjdk.jmh.runner.options.TimeValue;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.Throughput)
@OutputTimeUnit(TimeUnit.SECONDS)
@Fork(1)
public class GoodBench {

    public static double constant(double x1, double y1, double x2, double y2) {
        return 0.0;
    }

    public static double distance(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        return Math.sqrt((dx * dx) + (dy * dy));
    }

    @State(Scope.Thread)
    public static class Data {
        double x1 = 0.0;
        double y1 = 0.0;
        double x2 = 10.0;
        double y2 = 10.0;
    }

    // @Benchmark
    public void baseline_return_void() {

    }

    // @Benchmark
    public double baseline_return_zero() {
        return 0.0;
    }

    // @Benchmark
    public double constant(Data data) {
        return constant(data.x1, data.y1, data.x2, data.y2);
    }

    @Benchmark
    public double distance(Data data) {
        return distance(data.x1, data.y1, data.x2, data.y2);
    }
}